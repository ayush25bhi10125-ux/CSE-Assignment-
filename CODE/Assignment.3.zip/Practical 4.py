import time
import math
import tracemalloc

def is_pronic(n):
    if n < 0:
        return False, 0
    
    if n == 0:
        return True, 0

    limit = int(math.sqrt(n))
    
    for k in range(1, limit + 1):
        product = k * (k + 1)
        
        if product == n:
            return True, k
        
        if product > n:
            break
            
    return False, 0

numbers_to_test = [42, 110, 12, 18, 56, 9999900000, 100]

print("--- Pronic Number Check ---")
tracemalloc.start()
start_time = time.perf_counter()
start_time_iso = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(start_time))

for n in numbers_to_test:
    is_pronic_res, k_val = is_pronic(n)
    
    result_str = f"Pronic: {is_pronic_res}"
    if is_pronic_res:
        result_str += f" ({k_val} * {k_val + 1})"
    
    print(f"Number: {n: <12} | {result_str}")

end_time = time.perf_counter()
end_time_iso = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(end_time))
current_memory, peak_memory = tracemalloc.get_traced_memory()
tracemalloc.stop()
print("\n--- Execution Metrics ---")
print(f"1. Start Time: {start_time_iso}")
print(f"2. End Time:   {end_time_iso}")
print(f"3. Total Execution Time (seconds): {end_time - start_time:.6f}")
print(f"4. Peak Memory Used (KiB): {peak_memory / 1024:.2f}")
